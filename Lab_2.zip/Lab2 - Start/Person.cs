﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab2
{
	[Serializable]
	public class Person
	{
        public enum AgeGroupEnum 
        { 
            Unknown = 0,
            Child,
            Teen,
            Adult,
            Senior
        }

        private long m_ID = 0;

        public long ID
        {
            get { return m_ID; }
            set { m_ID = value; }
        }
        private string m_LastName = string.Empty;

        public string LastName
        {
            get { return m_LastName; }
            set { m_LastName = value; }
        }
        private string m_FirstName = string.Empty;

        public string FirstName
        {
            get { return m_FirstName; }
            set { m_FirstName = value; }
        }
        private DateTime m_DOB = DateTime.MinValue;

        public DateTime DOB
        {
            get { return m_DOB; }
            set { m_DOB = value; }
        }

        public int Age
        {
            get { 
                DateTime now = DateTime.Now;
                int years = now.Year - DOB.Year;
                if ((now.Month < DOB.Month) || ((now.Month == DOB.Month) && (now.Day < DOB.Day)))
                    years--; 
                return years;
                }
        }

        public AgeGroupEnum AgeGroup
        {
            get
            {
                if (Age < 13)
                    return AgeGroupEnum.Child;
                else if (Age < 19 && Age >= 13)
                    return AgeGroupEnum.Teen;
                else if (Age < 65 && Age >= 19)
                    return AgeGroupEnum.Adult;
                else
                    return AgeGroupEnum.Senior;

            }
        }

        public Person()
        {
        }

        public Person(long id, string lastName, string firstName, DateTime dob)
        {
            ID = id;
            LastName = lastName;
            FirstName = firstName;
            DOB = dob;
        }

        public override string ToString()
        {
            return string.Format("{0:000-00-0000} {1,-15} {2,-15} {3:MM/dd/yyyy}",ID, LastName, FirstName, DOB);
        }

	}
}
