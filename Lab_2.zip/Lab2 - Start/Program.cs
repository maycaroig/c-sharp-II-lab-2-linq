﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization.Formatters.Binary;
using System.Reflection;
using System.IO;

namespace Lab2
{
	class Program
	{
		private const string FILENAME = "people.data";
		private const string SEP = "====================";
		private const long RECORDS = 50000;

		static void Main(string[] args)
		{
			Console.BufferHeight = 9999;
			Console.WindowHeight = 50;

			// Uncomment to generate a new people file:
			// GeneratePeople();

			List<Person> people = OpenPersonFile();
			Console.WriteLine("{0} records read...", people.Count);

			GetYoungestAndOldest(people);

			GetNancysAndJohns(people);

			GetAgeGroups(people);

			LastInitialDistribution(people);

			GetCombinedNameLength(people);

			Console.ReadLine();
		}

		/// <summary>
		/// Get the youngest and oldest person
		/// </summary>
		/// <param name="people">Source data</param>
		static void GetYoungestAndOldest(List<Person> people)
		{
			// Find the youngest/oldest person
			Console.WriteLine("{2}{0} {1} {0}", SEP, "Youngest/Oldest", Environment.NewLine);
			
			// TODO
            var query = from p in people orderby p.DOB select p;

            Console.WriteLine("Youngest: {0} Oldest: {1}", query.First(), query.Last());

		}

		/// <summary>
		/// Get the distrbution of last initials (A - Z)
		/// </summary>
		/// <param name="people">Source data</param>
		static void LastInitialDistribution(List<Person> people)
		{
			// Get the counts of the starting letters of the peoples' last names
			Console.WriteLine("{2}{0} {1} {0}", SEP, "Last Name Disribution", Environment.NewLine);

			// TODO
            var query = from p in people group p by p.LastName[0] into distGroup select distGroup;

            foreach (var age in query)
            {
                Console.WriteLine("Age: {0} Count: {1}", age.Key, age.Count());
            }
		}

		/// <summary>
		/// Get all of the people whose first name is Nancy or John (A - Z)
		/// </summary>
		/// <param name="people">Source data</param>
		static void GetNancysAndJohns(List<Person> people)
		{
			// Find all people with the first name Nancy or John, order output by lastname, firstname, DOB
			// Output count of results
			Console.WriteLine("{2}{0} {1} {0}", SEP, "Nancy & John", Environment.NewLine);

			// TODO

            var query = from p in people
                        where p.FirstName == "Nancy" || p.FirstName == "John"
                        orderby p.LastName, p.FirstName, p.DOB
                        select p;
		}

		/// <summary>
		/// Get age groups
		/// </summary>
		/// <param name="people">Source data</param>
		static void GetAgeGroups(List<Person> people)
		{
			// Get the count of all Children (age < 13), teens (13 <= age <= 17), adults (18 <= age <= 64), seniors (age >= 65)
			// Hint: Use groups
			Console.WriteLine("{2}{0} {1} {0}", SEP, "Age Groups", Environment.NewLine);

			// TODO

            var query = from p in people group p by p.AgeGroup into ageGroup select ageGroup;

            foreach (var age in query) 
            { 
                Console.WriteLine("Age: {0} Count: {1}", age.Key, age.Count());
            }
		}

		/// <summary>
		/// Gets the list of people whose combine first and last names are 20 characters in length
		/// </summary>
		/// <param name="people">Source data</param>
		static void GetCombinedNameLength(List<Person> people)
		{
			// Get the list of all people where the combined length of their first and last name (combined with a comma and space) is 20.
			// Project the results into an anonymous type with one property "Name" that is concatenation
			// of the person's LastName, a comma, a space and FirstName.
			Console.WriteLine("{2}{0} {1} {0}", SEP, "20 Chars", Environment.NewLine);

			// TODO

            var query = (from p in people 
                        let name = p.LastName + ", " + p.FirstName
                            where name.Length == 20 
                        orderby name select new { Name = name }).Distinct();

            foreach (var name in query)
            {
             Console.WriteLine(name);
            }

		}
		
		#region IO Methods
		/// <summary>
		/// Opens the people file
		/// </summary>
		/// <returns></returns>
		private static List<Person> OpenPersonFile()
		{
			List<Person> people;
			BinaryFormatter bf = new BinaryFormatter();
			using (FileStream fs = new FileStream(FILENAME, FileMode.Open, FileAccess.Read))
			{
				people = bf.Deserialize(fs) as List<Person>;
			}
			return people;
		}

		/// <summary>
		/// Generates a new people file
		/// </summary>
		private static void GeneratePeople()
		{
			Random rnd = new Random();
			List<Person> people = new List<Person>();
			List<string> firstNames = new List<string>();
			List<string> lastNames = new List<string>();

			Assembly asm = Assembly.GetExecutingAssembly();

			// First Names
			using (StreamReader sr = new StreamReader(asm.GetManifestResourceStream("Lab2.FirstNames.txt")))
			{
				while (!sr.EndOfStream)
				{
					string name = sr.ReadLine().Trim().ToLower();
					if (!string.IsNullOrEmpty(name))
					{
						firstNames.Add(string.Format("{0}{1}", char.ToUpper(name[0]), name.Substring(1)));
					}
				}
			}

			// Last Names
			using (StreamReader sr = new StreamReader(asm.GetManifestResourceStream("Lab2.LastNames.txt")))
			{
				while (!sr.EndOfStream)
				{
					string name = sr.ReadLine().Trim().ToLower();
					if (!string.IsNullOrEmpty(name))
					{
						lastNames.Add(string.Format("{0}{1}", char.ToUpper(name[0]), name.Substring(1)));
					}
				}
			}

			// Create list of random people
			const long INCREMENT = 999999999L / RECORDS - 100L;
			long id = INCREMENT;
			for (long i = 0; i < RECORDS; i++)
			{
				id += INCREMENT + rnd.Next(1, 100);  // Add some randomness to IDs
				string lastName = lastNames[rnd.Next(0, lastNames.Count)];
				string firstName = firstNames[rnd.Next(0, firstNames.Count)];
				DateTime oldest = DateTime.Parse("1/1/1925");
				DateTime youngest = DateTime.Now;
				double oaDate = ((double)rnd.Next((int)oldest.ToOADate(), (int)youngest.ToOADate())) + rnd.NextDouble();
				Person person = new Person(id, lastName, firstName, DateTime.FromOADate(oaDate));
				people.Add(person);
			}

			// Save the person list to a file
			BinaryFormatter bf = new BinaryFormatter();
			using (FileStream fs = new FileStream(FILENAME, FileMode.Create, FileAccess.Write))
			{
				bf.Serialize(fs, people);
			}
		}
		#endregion IO Methods
	}
}
